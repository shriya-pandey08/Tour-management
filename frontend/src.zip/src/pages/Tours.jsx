import React from 'react'

const Tours = () => {
  return (
    <div>Tours</div>
  )
}

export default Tours;