import React from 'react'

const TourDetails = () => {
  return (
    <div>TourDetails</div>
  )
}

export default TourDetails;